/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

/**
 *
 * @author ACER A515-45-R3RR
 */
public class user_model {
//    private String id_user;
    private String name;
    private String email;
    private String password;
    private String role; // Role pengguna (ADMIN/USER)
    private String status; // Status verifikasi (NOT VERIFIED/VERIFIED)

    // Constructor
    public user_model(String name, String email, String password) {
        this.name = name;
        this.email = email;
        this.password = password;

        // Tentukan role dan status default
        this.role = password.equals("ADMINUSER") ? "ADMIN" : "USER";
        this.status = "NOT VERIFIED";
    }

    // Getter dan Setter
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }
    
    public void setRole(String role) {
        this.role = role;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
