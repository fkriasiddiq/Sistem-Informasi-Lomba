/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

/**
 *
 * @author ACER A515-45-R3RR
 */
public class competition_model {

    private String competitionName;
    private String category;
    private String startDate;
    private String endDate;
    private String competitionDate;
    private int registrationFee;
    private String facultyOrganizer;
    private String prizePool;
    private String description;

    // Constructor
    public competition_model(String competitionName, String category, String startDate, String endDate,
            String competitionDate, int registrationFee, String facultyOrganizer,
            String prizePool, String description) {
        this.competitionName = competitionName;
        this.category = category;
        this.startDate = startDate;
        this.endDate = endDate;
        this.competitionDate = competitionDate;
        this.registrationFee = registrationFee;
        this.facultyOrganizer = facultyOrganizer;
        this.prizePool = prizePool;
        this.description = description;
    }

    // Getters and Setters
    public String getCompetitionName() {
        return competitionName;
    }

    public void setCompetitionName(String competitionName) {
        this.competitionName = competitionName;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getCompetitionDate() {
        return competitionDate;
    }

    public void setCompetitionDate(String competitionDate) {
        this.competitionDate = competitionDate;
    }

    public int getRegistrationFee() {
        return registrationFee;
    }

    public void setRegistrationFee(int registrationFee) {
        this.registrationFee = registrationFee;
    }

    public String getFacultyOrganizer() {
        return facultyOrganizer;
    }

    public void setFacultyOrganizer(String facultyOrganizer) {
        this.facultyOrganizer = facultyOrganizer;
    }

    public String getPrizePool() {
        return prizePool;
    }

    public void setPrizePool(String prizePool) {
        this.prizePool = prizePool;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
