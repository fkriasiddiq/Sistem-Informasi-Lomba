/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controllers;

import models.user_model;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ACER A515-45-R3RR
 */
public class register_controller {

    private static List<user_model> users = new ArrayList<>(); // List untuk semua user

    // Method untuk mendaftarkan user baru
    public boolean registerUser(String name, String email, String password) {
        // Validasi: Email tidak boleh duplikat
        for (user_model user : users) {
            if (user.getEmail().equalsIgnoreCase(email)) {
                return false; // Gagal: Email sudah ada
            }
        }
        

        // Tambahkan pengguna baru
        user_model newUser = new user_model(name, email, password);
        users.add(newUser);
        return true; // Berhasil registrasi
    }

    // Fungsi untuk memperbarui data user berdasarkan ID
    public boolean updateUser(String email, String newName, String newEmail, String newRole, String newStatus) {
        for (user_model user : users) {
            if (user.getEmail().equalsIgnoreCase(email)) {
                // Update data user
                user.setName(newName);
                user.setEmail(newEmail);
                user.setRole(newRole);
                user.setStatus(newStatus);
                return true; // Berhasil memperbarui data
            }
        }
        return false; // Gagal: User tidak ditemukan
    }

    public boolean deleteUser(String email) {
        // Cari pengguna berdasarkan email
        for (user_model user : users) {
            if (user.getEmail().equalsIgnoreCase(email)) {
                users.remove(user); // Hapus pengguna dari daftar
                return true; // Penghapusan berhasil
            }
        }
        return false; // Pengguna tidak ditemukan
    }

    // Dapatkan daftar semua user
    public List<user_model> getAllUsers() {
        return users;
    }

    // Dapatkan daftar admin
    public List<user_model> getAdmins() {
        List<user_model> admins = new ArrayList<>();
        for (user_model user : users) {
            if (user.getRole().equals("ADMIN")) {
                admins.add(user);
            }
        }
        return admins;
    }

    // Dapatkan daftar user biasa
    public List<user_model> getUsers() {
        List<user_model> regularUsers = new ArrayList<>();
        for (user_model user : users) {
            if (user.getRole().equals("USER")) {
                regularUsers.add(user);
            }
        }
        return regularUsers;
    }
}
