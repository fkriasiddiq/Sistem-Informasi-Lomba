/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controllers;

import models.competition_model;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ACER A515-45-R3RR
 */
public class competition_controller {

    private static List<competition_model> competitions = new ArrayList<>();

    // Method untuk menambahkan kompetisi baru
    public boolean addCompetition(competition_model competition) {
        // Validasi: Nama kompetisi tidak boleh duplikat
        for (competition_model existingCompetition : competitions) {
            if (existingCompetition.getCompetitionName().equalsIgnoreCase(competition.getCompetitionName())) {
                return false; // Gagal: Nama kompetisi sudah ada
            }
        }

        competitions.add(competition); // Tambahkan ke list
        return true; // Berhasil
    }

    // Method untuk mendapatkan semua kompetisi
    public List<competition_model> getAllCompetitions() {
        return competitions; // Mengembalikan list kompetisi
    }

    // Method untuk memperbarui data kompetisi
    public boolean updateCompetition(int competitionIndex, competition_model updatedCompetition) {
        if (competitionIndex >= 0 && competitionIndex < competitions.size()) {
            competitions.set(competitionIndex, updatedCompetition); // Update data kompetisi berdasarkan indeks
            return true; // Berhasil memperbarui
        }
        return false; // Gagal: Indeks tidak valid
    }

    // Method untuk menghapus kompetisi berdasarkan nama
    public boolean deleteCompetition(int index) {
        if (index >= 0 && index < competitions.size()) {
            competitions.remove(index); // Hapus kompetisi berdasarkan index
            return true; // Berhasil dihapus
        }
        return false; // Gagal: Index tidak valid
    }

}
