/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controllers;

import models.user_model;
import java.util.List;

/**
 *
 * @author ACER A515-45-R3RR
 */
public class login_controller {

    private register_controller registerController;

    public login_controller(register_controller registerController) {
        this.registerController = registerController;
    }

    /**
     * Login method to authenticate user.
     *
     * @param email The email input
     * @param password The password input
     * @return The user_model object if login is successful, null otherwise
     */
    public user_model loginAndGetUser(String email, String password) {
        List<user_model> users = registerController.getAllUsers();
        for (user_model user : users) {
            if (user.getEmail().equalsIgnoreCase(email) && user.getPassword().equals(password)) {
                if (user.getStatus().equals("VERIFIED")) {
                    return user; // Return user yang berhasil login
                }
            }
        }
        return null; // Gagal login
    }
}
