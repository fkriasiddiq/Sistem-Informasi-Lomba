/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package main.comp_info;

import controllers.register_controller;
import views.login_form;

import views.contest_information_page;
import controllers.competition_controller;

/**
 *
 * @author ACER A515-45-R3RR
 */
public class main {

    public static void main(String[] args) {
        // Menjalankan GUI Login Form
        
        // controller utk halaman login 
//        register_controller registerController = new register_controller();
        
//        Uncomment kode di bawah ini jika ingin dimulai dari login page
//        new login_form(registerController).setVisible(true);
        
        
        // controller utk halaman informasi lomba
        competition_controller controller = new competition_controller();

//        Uncomment bagian ini jika ingin dimulai dari halaman informasi lomba
        new contest_information_page(controller).setVisible(true);
        
    }
}
