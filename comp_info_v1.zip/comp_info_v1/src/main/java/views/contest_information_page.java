/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package views;

import controllers.competition_controller;
import controllers.register_controller;
import models.competition_model;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import javax.swing.JFrame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.stream.Collectors;
import wrapLayout.WrapLayout;

/**
 *
 * @author ACER A515-45-R3RR
 */
public class contest_information_page extends JFrame {

    private competition_controller controller;
    private JPanel mainPanel;
    private JTextField searchField;
    private JButton searchButton;
    private JButton resetButton;
    private JScrollPane scrollPane;

    public contest_information_page(competition_controller controller) {
        this.controller = controller;

        setTitle("Informasi Lomba");
        setSize(1300, 700);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null);
        setBackground(Color.WHITE);

        // Panel Gabungan untuk Header dan Search
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.Y_AXIS));

        // Panel Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Color.decode("#D3D3D3")); // Warna abu-abu muda

        // Label untuk judul
        JLabel titleLabel = new JLabel("Contest Information Center");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setForeground(Color.decode("#074C78")); // Warna teks hitam
        titleLabel.setHorizontalAlignment(SwingConstants.LEFT);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Padding teks

        headerPanel.add(titleLabel, BorderLayout.WEST); // Tambahkan ke sisi kiri header

        // Panel untuk tombol Login dan Register
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        buttonPanel.setBackground(Color.decode("#D3D3D3")); // Sama dengan warna header

        JButton loginButton = new JButton("Login");
        JButton registerButton = new JButton("Register");

        // Atur gaya tombol
        loginButton.setBackground(Color.decode("#074C78"));
        loginButton.setForeground(Color.WHITE);
        loginButton.setFocusPainted(false);
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Aksi untuk membuka form login
                register_controller registerController = new register_controller();
                new login_form(registerController).setVisible(true);
                // dispose(); // Tutup halaman saat ini
            }
        });

        registerButton.setBackground(Color.decode("#074C78"));
        registerButton.setForeground(Color.WHITE);
        registerButton.setFocusPainted(false);
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Aksi untuk membuka form register
                new register_form().setVisible(true);
                // dispose(); // Tutup halaman saat ini
            }
        });

        // Tambahkan tombol ke panel
        buttonPanel.add(loginButton);
        buttonPanel.add(registerButton);

        headerPanel.add(buttonPanel, BorderLayout.EAST); // Tambahkan panel tombol ke sisi kanan header

        // Tambahkan bagian teks di bawah header
        JPanel bannerPanel = new JPanel();
        bannerPanel.setBackground(Color.decode("#074C78")); // Background putih
        bannerPanel.setLayout(new BoxLayout(bannerPanel, BoxLayout.Y_AXIS));
        bannerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Padding: atas, kiri, bawah, kanan

        // Judul besar
        JLabel mainTitle = new JLabel("Jadilah Juara di Kampus Biru");
        mainTitle.setFont(new Font("Arial", Font.BOLD, 20));
        mainTitle.setForeground(Color.WHITE); // Warna biru
        mainTitle.setAlignmentX(Component.CENTER_ALIGNMENT); // Pusatkan teks

        // Deskripsi di bawahnya
        JLabel description = new JLabel("<html><div style='text-align: center;'>Temukan berbagai informasi lomba terkini untuk mengembangkan potensi diri, raih prestasi gemilang, dan jadilah kebanggaan kampus!</div></html>");
        description.setFont(new Font("Arial", Font.PLAIN, 14));
        description.setForeground(Color.WHITE);
        description.setAlignmentX(Component.CENTER_ALIGNMENT); // Pusatkan teks

// Tambahkan ke panel banner
        bannerPanel.add(mainTitle);
        bannerPanel.add(Box.createRigidArea(new Dimension(0, 10))); // Spasi vertikal antara judul dan deskripsi
        bannerPanel.add(description);

        // Panel Pencarian
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        searchField = new JTextField(20);
        searchButton = new JButton("Cari");
        resetButton = new JButton("Reset");
        searchPanel.add(new JLabel("Cari Lomba:"));
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
        searchPanel.add(resetButton);

        // Tambahkan headerPanel, bannerPanel dan searchPanel ke panel gabungan
        topPanel.add(headerPanel);
        topPanel.add(searchPanel);
        topPanel.add(bannerPanel);

        // Tambahkan panel gabungan ke bagian atas frame
        add(topPanel, BorderLayout.NORTH);

        // Panel Utama
        mainPanel = new JPanel();
        mainPanel.setLayout(new WrapLayout(FlowLayout.LEFT, 10, 10)); // WrapLayout untuk menyusun panel horizontal 3 per baris
        scrollPane = new JScrollPane(mainPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        add(scrollPane, BorderLayout.CENTER);

        // Event Listeners Untuk Tombol Pencarian
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                searchCompetitions();
            }
        });

        // Event Listeners Untuk Tombol Reset
        resetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                resetSearch();
            }
        });

        // Tampilkan Data Awal
        displayCompetitions(controller.getAllCompetitions());
    }

    private void displayCompetitions(List<competition_model> competitions) {
        mainPanel.removeAll(); // Hapus semua komponen yang ada di mainPanel
        mainPanel.revalidate(); // Validasi ulang layout panel
        mainPanel.repaint(); // Perbarui tampilan panel

        if (competitions.isEmpty()) {
            JLabel noDataLabel = new JLabel("Belum Ada Informasi Lomba Terkini, Terus Semangat Untuk Mengembangkan Diri");
            noDataLabel.setHorizontalAlignment(SwingConstants.CENTER);
            noDataLabel.setForeground(Color.GRAY); // Tambahkan warna teks abu-abu untuk pesan
            noDataLabel.setFont(new Font("Arial", Font.ITALIC, 14)); // Teks gaya miring
            mainPanel.add(noDataLabel);
        } else {
            for (competition_model competition : competitions) {
                JPanel panel = new JPanel();
                panel.setPreferredSize(new Dimension(240, 135));
                panel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
                panel.setLayout(new BorderLayout()); // Gunakan BorderLayout untuk kontrol layout

                // Panel untuk nama lomba dengan warna biru dan teks tebal
                JPanel headerPanel = new JPanel();
                headerPanel.setBackground(Color.decode("#074C78")); // Warna biru untuk header
                headerPanel.setPreferredSize(new Dimension(240, 30));
                headerPanel.setLayout(new BorderLayout());

                JLabel nameLabel = new JLabel(competition.getCompetitionName());
                nameLabel.setForeground(Color.WHITE); // Teks warna putih
                nameLabel.setFont(new Font("Arial", Font.BOLD, 14)); // Teks tebal
                nameLabel.setHorizontalAlignment(SwingConstants.CENTER);
                headerPanel.add(nameLabel, BorderLayout.CENTER);

                // Panel isi dengan padding dan informasi
                JPanel contentPanel = new JPanel();
                contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
                contentPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Padding: atas, kiri, bawah, kanan
                contentPanel.setBackground(UIManager.getColor("Panel.background")); // Warna abu-abu default

                contentPanel.add(new JLabel("Kategori: " + competition.getCategory()));
                contentPanel.add(new JLabel("Fakultas: " + competition.getFacultyOrganizer()));
                contentPanel.add(new JLabel("Awal Pendaftaran: " + competition.getStartDate()));
                contentPanel.add(new JLabel("Batas Pendaftaran: " + competition.getEndDate()));
                contentPanel.add(new JLabel("Tanggal Pelaksanaan: " + competition.getCompetitionDate()));

                panel.add(headerPanel, BorderLayout.NORTH); // Tambahkan header ke atas panel
                panel.add(contentPanel, BorderLayout.CENTER); // Tambahkan isi ke tengah panel

                // Tambahkan MouseListener untuk menangani klik
                panel.addMouseListener(new java.awt.event.MouseAdapter() {
                    @Override
                    public void mouseClicked(java.awt.event.MouseEvent evt) {
                        String detail = "Informasi Lomba:\n"
                                + "Nama: " + competition.getCompetitionName() + "\n"
                                + "Kategori: " + competition.getCategory() + "\n"
                                + "Fakultas: " + competition.getFacultyOrganizer() + "\n"
                                + "Awal Pendaftaran: " + competition.getStartDate() + "\n"
                                + "Batas Pendaftaran: " + competition.getEndDate() + "\n"
                                + "Tanggal Pelaksanaan: " + competition.getCompetitionDate() + "\n"
                                + "Biaya Pendaftaran: " + competition.getRegistrationFee() + "\n"
                                + "Hadiah: " + competition.getPrizePool() + "\n"
                                + "Deskripsi: " + competition.getDescription();

                        // Tampilkan JOptionPane di tengah layar
                        JOptionPane pane = new JOptionPane(detail, JOptionPane.INFORMATION_MESSAGE);
                        JDialog dialog = pane.createDialog(null, "Detail Lomba");
                        dialog.setLocationRelativeTo(null); // Pusatkan secara horizontal dan vertikal
                        dialog.setVisible(true);
                    }
                });

                mainPanel.add(panel);
            }
        }

        mainPanel.revalidate(); // Validasi ulang layout panel setelah menambahkan komponen baru
        mainPanel.repaint(); // Perbarui tampilan panel
    }

    private void searchCompetitions() {
        String keyword = searchField.getText().trim().toLowerCase();
        if (keyword.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Masukkan kata kunci untuk mencari!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Filter kompetisi berdasarkan kata kunci (tidak melibatkan angka/tanggal)
        List<competition_model> filteredCompetitions = controller.getAllCompetitions().stream()
                .filter(comp -> comp.getCompetitionName().toLowerCase().contains(keyword)
                || comp.getCategory().toLowerCase().contains(keyword)
                || comp.getFacultyOrganizer().toLowerCase().contains(keyword)
                || comp.getDescription().toLowerCase().contains(keyword))
                .collect(Collectors.toList());

        displayCompetitions(filteredCompetitions);

        if (filteredCompetitions.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Tidak ada lomba yang ditemukan dengan kata kunci: " + keyword, "Hasil Pencarian", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void resetSearch() {
        searchField.setText("");
        displayCompetitions(controller.getAllCompetitions());
    }
}
